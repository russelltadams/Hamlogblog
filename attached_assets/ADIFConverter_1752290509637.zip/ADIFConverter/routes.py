import os
import json
from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, jsonify, send_file, Response, session
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge
import io
import math

from app import app, admin_required, ADMIN_USERNAME, ADMIN_PASSWORD
from models import log_manager
from adif_parser import AdifParser
from qsl_generator import QSLGenerator

# Configure allowed file extensions
ALLOWED_EXTENSIONS = {'adi', 'adif', 'txt'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def paginate_list(items, page, per_page):
    """Helper function to paginate a list"""
    total = len(items)
    pages = math.ceil(total / per_page)
    start = (page - 1) * per_page
    end = start + per_page
    
    return {
        'items': items[start:end],
        'page': page,
        'pages': pages,
        'per_page': per_page,
        'total': total,
        'has_prev': page > 1,
        'has_next': page < pages,
        'prev_num': page - 1 if page > 1 else None,
        'next_num': page + 1 if page < pages else None
    }

@app.route('/')
def index():
    """Public log blog - show recent contacts, stats, and latest blog entries"""
    log_stats = log_manager.get_log_stats()
    
    # Get recent contacts for display (limit to 10)
    all_contacts = log_manager.get_all_contacts()
    
    # Add index to each contact for template linking
    for i, contact in enumerate(all_contacts):
        contact['index'] = i
    
    # Sort by date descending (most recent first)
    all_contacts.sort(key=lambda x: (x.get('qso_date', ''), x.get('time_on', '')), reverse=True)
    
    # Limit to recent 10 contacts for home page
    recent_contacts = all_contacts[:10]
    
    # Get latest 4 blog entries
    latest_blog_posts = log_manager.get_blog_posts(limit=4)
    
    return render_template('public_log.html', 
                         log_stats=log_stats, 
                         contacts=recent_contacts, 
                         blog_posts=latest_blog_posts)

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """Admin login page"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            flash('Successfully logged in as admin', 'success')
            return redirect(url_for('admin_panel'))
        else:
            flash('Invalid credentials', 'error')
    
    return render_template('admin_login.html')

@app.route('/admin/logout')
@admin_required
def admin_logout():
    """Admin logout"""
    session.pop('admin_logged_in', None)
    flash('Logged out successfully', 'info')
    return redirect(url_for('index'))

@app.route('/admin')
@admin_required
def admin_panel():
    """Admin panel with upload form and log stats"""
    log_stats = log_manager.get_log_stats()
    return render_template('admin_panel.html', log_stats=log_stats)

@app.route('/admin/upload', methods=['POST'])
@admin_required
def upload_file():
    """Handle ADIF file upload and processing - Admin only"""
    try:
        if 'file' not in request.files:
            flash('No file selected', 'error')
            return redirect(url_for('index'))
        
        file = request.files['file']
        
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(url_for('index'))
        
        if not allowed_file(file.filename):
            flash('Invalid file type. Please upload .adi, .adif, or .txt files only.', 'error')
            return redirect(url_for('index'))
        
        # Save uploaded file temporarily
        filename = secure_filename(file.filename or 'upload.adi')
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_')
        filename = timestamp + filename
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Parse ADIF file
        parser = AdifParser()
        header_info, contacts_data = parser.parse_file(filepath)
        
        if not contacts_data:
            flash('No valid contacts found in the uploaded file', 'warning')
            os.remove(filepath)  # Clean up
            return redirect(url_for('index'))
        
        # Add contacts to JSON log
        result = log_manager.add_contacts(contacts_data)
        
        # Clean up uploaded file
        os.remove(filepath)
        
        # Provide detailed feedback about the import
        messages = []
        if result['added'] > 0:
            messages.append(f'Added {result["added"]} new contacts')
        if result['updated'] > 0:
            messages.append(f'Updated {result["updated"]} existing contacts with new data')
        if result['duplicates'] > 0:
            messages.append(f'Skipped {result["duplicates"]} unchanged duplicates')
        
        if messages:
            flash(f'Import complete: {", ".join(messages)}', 'success')
        else:
            flash('No changes made - all contacts were identical to existing data', 'info')
        
        return redirect(url_for('view_log'))
        
    except RequestEntityTooLarge:
        flash('File too large. Maximum file size is 16MB.', 'error')
        return redirect(url_for('index'))
    except Exception as e:
        app.logger.error(f"Error processing upload: {str(e)}")
        flash(f'Error processing file: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/log')
def view_log():
    """View all contacts in the log"""
    page = request.args.get('page', 1, type=int)
    per_page = 50
    
    all_contacts = log_manager.get_all_contacts()
    
    # Sort by date descending, then by time
    sorted_contacts = sorted(all_contacts, key=lambda x: (
        x.get('qso_date', ''), 
        x.get('time_on', '')
    ), reverse=True)
    
    # Add index to each contact
    for i, contact in enumerate(sorted_contacts):
        contact['index'] = i
    
    contacts = paginate_list(sorted_contacts, page, per_page)
    log_stats = log_manager.get_log_stats()
    
    return render_template('view_log.html', contacts=contacts, log_stats=log_stats)

@app.route('/contact/<int:contact_index>')
def view_contact(contact_index):
    """View detailed information for a specific contact"""
    contact = log_manager.get_contact_by_index(contact_index)
    if not contact:
        flash('Contact not found', 'error')
        return redirect(url_for('view_log'))
    
    return render_template('view_contact.html', contact=contact)

@app.route('/search')
def search():
    """Search contacts across the log"""
    query = request.args.get('q', '').strip()
    call = request.args.get('call', '').strip()
    band = request.args.get('band', '').strip()
    mode = request.args.get('mode', '').strip()
    date_from = request.args.get('date_from', '').strip()
    date_to = request.args.get('date_to', '').strip()
    
    page = request.args.get('page', 1, type=int)
    per_page = 50
    
    # Search contacts
    search_results = log_manager.search_contacts(
        query=query, call=call, band=band, mode=mode, 
        date_from=date_from, date_to=date_to
    )
    
    # Sort results by date descending
    sorted_results = sorted(search_results, key=lambda x: (
        x.get('qso_date', ''), 
        x.get('time_on', '')
    ), reverse=True)
    
    contacts = paginate_list(sorted_results, page, per_page)
    
    # Get available bands and modes for filter dropdowns
    bands = log_manager.get_bands()
    modes = log_manager.get_modes()
    
    return render_template('search.html', 
                         contacts=contacts,
                         bands=bands,
                         modes=modes,
                         search_params={
                             'q': query,
                             'call': call,
                             'band': band,
                             'mode': mode,
                             'date_from': date_from,
                             'date_to': date_to
                         })

@app.route('/admin/export/json')
@admin_required
def export_json():
    """Export log as JSON - Admin only"""
    json_data = log_manager.export_json()
    
    # Create filename with timestamp
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"KM6KFX_log_{timestamp}.json"
    
    return Response(
        json_data,
        mimetype='application/json',
        headers={'Content-Disposition': f'attachment; filename={filename}'}
    )

@app.route('/admin/export/adif')
@admin_required
def export_adif():
    """Export log as ADIF - Admin only"""
    adif_data = log_manager.export_adif()
    
    # Create filename with timestamp
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"KM6KFX_log_{timestamp}.adi"
    
    return Response(
        adif_data,
        mimetype='text/plain',
        headers={'Content-Disposition': f'attachment; filename={filename}'}
    )

@app.route('/qsl/<int:contact_index>')
def generate_qsl(contact_index):
    """Generate QSL card for a specific contact"""
    contact = log_manager.get_contact_by_index(contact_index)
    if not contact:
        flash('Contact not found', 'error')
        return redirect(url_for('view_log'))
    
    try:
        generator = QSLGenerator()
        
        # Get station info
        station_info = {'callsign': 'KM6KFX'}
        
        card_data = generator.generate_qsl_card(contact, station_info)
        
        filename = f"QSL_{contact.get('call', 'unknown')}_{contact.get('qso_date', 'unknown')}.png"
        
        return send_file(
            io.BytesIO(card_data),
            mimetype='image/png',
            as_attachment=True,
            download_name=filename
        )
        
    except Exception as e:
        app.logger.error(f"Error generating QSL card: {str(e)}")
        flash('Error generating QSL card', 'error')
        return redirect(url_for('view_log'))

@app.errorhandler(413)
def too_large(e):
    flash('File too large. Maximum file size is 16MB.', 'error')
    return redirect(url_for('index'))

@app.errorhandler(404)
def not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500

@app.route('/blog')
def blog():
    """Blog page showing all blog posts"""
    blog_posts = log_manager.get_blog_posts()
    return render_template('blog.html', blog_posts=blog_posts)

@app.route('/blog/<int:post_id>')
def blog_post(post_id):
    """Individual blog post page"""
    post = log_manager.get_blog_post(post_id)
    if not post:
        flash('Blog post not found', 'error')
        return redirect(url_for('blog'))
    return render_template('blog_post.html', post=post)

@app.route('/admin/blog')
@admin_required
def admin_blog():
    """Admin blog management page"""
    blog_posts = log_manager.get_blog_posts()
    return render_template('admin_blog.html', blog_posts=blog_posts)

@app.route('/admin/blog/new', methods=['GET', 'POST'])
@admin_required
def admin_blog_new():
    """Create new blog post"""
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        content = request.form.get('content', '').strip()
        date = request.form.get('date', '').strip()
        
        if not title or not content:
            flash('Title and content are required', 'error')
            return render_template('admin_blog_edit.html', post=None)
        
        new_post = log_manager.add_blog_post(title, content, date or None)
        flash(f'Blog post "{title}" created successfully', 'success')
        return redirect(url_for('admin_blog'))
    
    return render_template('admin_blog_edit.html', post=None)

@app.route('/admin/blog/<int:post_id>/edit', methods=['GET', 'POST'])
@admin_required
def admin_blog_edit(post_id):
    """Edit existing blog post"""
    post = log_manager.get_blog_post(post_id)
    if not post:
        flash('Blog post not found', 'error')
        return redirect(url_for('admin_blog'))
    
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        content = request.form.get('content', '').strip()
        date = request.form.get('date', '').strip()
        
        if not title or not content:
            flash('Title and content are required', 'error')
            return render_template('admin_blog_edit.html', post=post)
        
        updated_post = log_manager.update_blog_post(post_id, title, content, date or None)
        if updated_post:
            flash(f'Blog post "{title}" updated successfully', 'success')
            return redirect(url_for('admin_blog'))
        else:
            flash('Error updating blog post', 'error')
    
    return render_template('admin_blog_edit.html', post=post)

@app.route('/admin/blog/<int:post_id>/delete', methods=['POST'])
@admin_required
def admin_blog_delete(post_id):
    """Delete blog post"""
    post = log_manager.get_blog_post(post_id)
    if not post:
        flash('Blog post not found', 'error')
        return redirect(url_for('admin_blog'))
    
    if log_manager.delete_blog_post(post_id):
        flash(f'Blog post "{post["title"]}" deleted successfully', 'success')
    else:
        flash('Error deleting blog post', 'error')
    
    return redirect(url_for('admin_blog'))