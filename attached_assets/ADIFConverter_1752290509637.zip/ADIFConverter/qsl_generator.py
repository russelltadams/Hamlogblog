from PIL import Image, ImageDraw, ImageFont
from datetime import datetime
import io
import os
import logging

logger = logging.getLogger(__name__)

class QSLGenerator:
    """Generate QSL cards from contact information"""
    
    def __init__(self):
        self.card_width = 600
        self.card_height = 400
        self.margin = 20
        
        # Colors (for light mode compatibility)
        self.bg_color = (255, 255, 255)  # White background
        self.text_color = (0, 0, 0)      # Black text
        self.accent_color = (0, 100, 200) # Blue accent
        self.border_color = (100, 100, 100) # Gray border
        
    def generate_qsl_card(self, contact_data, station_info=None):
        """Generate a QSL card image for a contact"""
        try:
            # Create image
            img = Image.new('RGB', (self.card_width, self.card_height), self.bg_color)
            draw = ImageDraw.Draw(img)
            
            # Try to load fonts, fall back to default if not available
            try:
                title_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 24)
                header_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 16)
                normal_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12)
                small_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 10)
            except OSError:
                # Fall back to default font
                title_font = ImageFont.load_default()
                header_font = ImageFont.load_default()
                normal_font = ImageFont.load_default()
                small_font = ImageFont.load_default()
            
            # Draw border
            draw.rectangle([5, 5, self.card_width-5, self.card_height-5], 
                          outline=self.border_color, width=2)
            
            # Title section
            y_pos = self.margin
            
            # QSL confirmation title
            title_text = "QSL CONFIRMATION"
            title_bbox = draw.textbbox((0, 0), title_text, font=title_font)
            title_x = (self.card_width - (title_bbox[2] - title_bbox[0])) // 2
            draw.text((title_x, y_pos), title_text, fill=self.accent_color, font=title_font)
            y_pos += 35
            
            # Station callsign
            station_call = contact_data.get('station_callsign', station_info.get('callsign', 'N0CALL') if station_info else 'N0CALL')
            call_text = f"Station: {station_call}"
            call_bbox = draw.textbbox((0, 0), call_text, font=header_font)
            call_x = (self.card_width - (call_bbox[2] - call_bbox[0])) // 2
            draw.text((call_x, y_pos), call_text, fill=self.text_color, font=header_font)
            y_pos += 30
            
            # Contact information section
            draw.line([self.margin, y_pos, self.card_width - self.margin, y_pos], 
                     fill=self.border_color, width=1)
            y_pos += 15
            
            # Contact details in two columns
            left_col_x = self.margin
            right_col_x = self.card_width // 2 + 10
            
            # Left column
            contact_lines = [
                f"Call: {contact_data.get('call', 'N/A')}",
                f"Date: {contact_data.get('qso_date', 'N/A')}",
                f"Time: {contact_data.get('time_on', 'N/A')} UTC",
                f"Band: {contact_data.get('band', 'N/A')}",
                f"Mode: {contact_data.get('mode', 'N/A')}"
            ]
            
            for line in contact_lines:
                draw.text((left_col_x, y_pos), line, fill=self.text_color, font=normal_font)
                y_pos += 18
            
            # Right column
            y_pos -= len(contact_lines) * 18  # Reset y position for right column
            
            # Handle RST reports based on mode
            mode = contact_data.get('mode', '')
            digital_modes = ['FT8', 'FT4', 'JS8', 'MSK144', 'JT65', 'JT9', 'PSK31', 'RTTY', 'MFSK']
            
            if mode in digital_modes:
                rst_sent_text = f"RST Sent: N/A ({mode})"
                rst_rcvd_text = f"RST Rcvd: N/A ({mode})"
            else:
                rst_sent_text = f"RST Sent: {contact_data.get('rst_sent', 'N/A')}"
                rst_rcvd_text = f"RST Rcvd: {contact_data.get('rst_rcvd', 'N/A')}"
            
            right_lines = [
                f"Freq: {contact_data.get('freq', 'N/A')} MHz" if contact_data.get('freq') else "Freq: N/A",
                rst_sent_text,
                rst_rcvd_text,
                f"Grid: {contact_data.get('gridsquare', 'N/A')}",
                f"QTH: {contact_data.get('state', contact_data.get('country', 'N/A'))}"
            ]
            
            for line in right_lines:
                draw.text((right_col_x, y_pos), line, fill=self.text_color, font=normal_font)
                y_pos += 18
            
            # Confirmation section
            y_pos += 20
            draw.line([self.margin, y_pos, self.card_width - self.margin, y_pos], 
                     fill=self.border_color, width=1)
            y_pos += 15
            
            confirm_text = "This QSO is confirmed"
            confirm_bbox = draw.textbbox((0, 0), confirm_text, font=header_font)
            confirm_x = (self.card_width - (confirm_bbox[2] - confirm_bbox[0])) // 2
            draw.text((confirm_x, y_pos), confirm_text, fill=self.accent_color, font=header_font)
            y_pos += 30
            
            # QSL info
            qsl_sent = contact_data.get('qsl_sent', 'N')
            qsl_rcvd = contact_data.get('qsl_rcvd', 'N')
            
            qsl_info = f"QSL Sent: {qsl_sent}   QSL Rcvd: {qsl_rcvd}"
            draw.text((left_col_x, y_pos), qsl_info, fill=self.text_color, font=normal_font)
            
            # Footer
            footer_y = self.card_height - 30
            footer_text = f"Generated on {datetime.now().strftime('%Y-%m-%d')}"
            draw.text((self.margin, footer_y), footer_text, fill=self.text_color, font=small_font)
            
            # Convert to bytes
            img_buffer = io.BytesIO()
            img.save(img_buffer, format='PNG', quality=95)
            img_buffer.seek(0)
            
            return img_buffer.getvalue()
            
        except Exception as e:
            logger.error(f"Error generating QSL card: {str(e)}")
            raise
    
    def generate_batch_qsl_cards(self, contacts, station_info=None):
        """Generate QSL cards for multiple contacts"""
        cards = []
        
        for contact in contacts:
            try:
                card_data = self.generate_qsl_card(contact, station_info)
                cards.append({
                    'call': contact.get('call', 'Unknown'),
                    'date': contact.get('qso_date', 'Unknown'),
                    'card_data': card_data
                })
            except Exception as e:
                logger.error(f"Error generating card for {contact.get('call', 'Unknown')}: {str(e)}")
                continue
        
        return cards
