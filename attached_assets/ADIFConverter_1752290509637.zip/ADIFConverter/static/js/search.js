// Search functionality enhancements
document.addEventListener('DOMContentLoaded', function() {
    // Auto-submit search form on certain field changes
    const searchForm = document.querySelector('form[method="GET"]');
    const autoSubmitFields = ['band', 'mode'];
    
    if (searchForm) {
        autoSubmitFields.forEach(fieldName => {
            const field = searchForm.querySelector(`[name="${fieldName}"]`);
            if (field) {
                field.addEventListener('change', function() {
                    // Small delay to improve UX
                    setTimeout(() => {
                        searchForm.submit();
                    }, 100);
                });
            }
        });
    }
    
    // Enhanced call sign input formatting
    const callInput = document.querySelector('input[name="call"]');
    if (callInput) {
        callInput.addEventListener('input', function() {
            // Convert to uppercase and remove invalid characters
            let value = this.value.replace(/[^A-Z0-9\/]/gi, '').toUpperCase();
            this.value = value;
        });
    }
    
    // Date range validation
    const dateFromInput = document.querySelector('input[name="date_from"]');
    const dateToInput = document.querySelector('input[name="date_to"]');
    
    if (dateFromInput && dateToInput) {
        function validateDateRange() {
            const fromDate = dateFromInput.value;
            const toDate = dateToInput.value;
            
            if (fromDate && toDate && fromDate > toDate) {
                dateToInput.setCustomValidity('End date must be after start date');
            } else {
                dateToInput.setCustomValidity('');
            }
        }
        
        dateFromInput.addEventListener('change', validateDateRange);
        dateToInput.addEventListener('change', validateDateRange);
    }
    
    // Search suggestions (basic implementation)
    const generalSearchInput = document.querySelector('input[name="q"]');
    if (generalSearchInput) {
        let searchTimeout;
        
        generalSearchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            const query = this.value.trim();
            
            if (query.length >= 2) {
                searchTimeout = setTimeout(() => {
                    // Could implement search suggestions here
                    // For now, just update placeholder text
                    updateSearchPlaceholder(query);
                }, 300);
            }
        });
    }
    
    function updateSearchPlaceholder(query) {
        // Simple heuristic to suggest search type
        if (/^[A-Z0-9\/]{3,}$/i.test(query)) {
            generalSearchInput.placeholder = 'Searching call signs...';
        } else if (/^\d{1,2}M$/i.test(query)) {
            generalSearchInput.placeholder = 'Searching bands...';
        } else {
            generalSearchInput.placeholder = 'Call, country, state...';
        }
    }
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + K to focus search
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            const searchInput = document.querySelector('input[name="q"]');
            if (searchInput) {
                searchInput.focus();
                searchInput.select();
            }
        }
        
        // Escape to clear search
        if (e.key === 'Escape') {
            const activeElement = document.activeElement;
            if (activeElement && activeElement.tagName === 'INPUT') {
                activeElement.blur();
            }
        }
    });
    
    // Table row highlighting
    const tableRows = document.querySelectorAll('tbody tr');
    tableRows.forEach(row => {
        row.addEventListener('mouseenter', function() {
            this.style.backgroundColor = 'var(--bs-gray-800)';
        });
        
        row.addEventListener('mouseleave', function() {
            this.style.backgroundColor = '';
        });
    });
    
    // Dropdown improvements
    const dropdownButtons = document.querySelectorAll('[data-bs-toggle="dropdown"]');
    dropdownButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    });
});

// Utility functions
function formatCallSign(callsign) {
    return callsign.replace(/[^A-Z0-9\/]/gi, '').toUpperCase();
}

function isValidCallSign(callsign) {
    // Basic amateur radio call sign validation
    const callPattern = /^[A-Z0-9]{1,3}[0-9][A-Z0-9]{0,3}[A-Z]$/i;
    return callPattern.test(callsign);
}

function formatFrequency(freq) {
    const frequency = parseFloat(freq);
    if (isNaN(frequency)) return '';
    
    if (frequency < 1) {
        return (frequency * 1000).toFixed(0) + ' kHz';
    } else if (frequency < 1000) {
        return frequency.toFixed(3) + ' MHz';
    } else {
        return (frequency / 1000).toFixed(3) + ' GHz';
    }
}

// Export functions for use in other scripts
window.adifUtils = {
    formatCallSign,
    isValidCallSign,
    formatFrequency
};
