import json
import os
from datetime import datetime, date, time
from typing import Dict, List, Any, Optional

class LogManager:
    """Manages the single JSON log file for the station"""
    
    def __init__(self, log_file='station_log.json', blog_file='blog_posts.json'):
        self.log_file = log_file
        self.blog_file = blog_file
        self.data = self._load_log()
        self.blog_data = self._load_blog()
    
    def _load_log(self) -> Dict[str, Any]:
        """Load log data from JSON file"""
        if os.path.exists(self.log_file):
            try:
                with open(self.log_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        
        # Return default structure
        return {
            'station_info': {
                'callsign': 'KM6KFX',
                'created_date': datetime.now().isoformat(),
                'last_updated': datetime.now().isoformat()
            },
            'contacts': [],
            'metadata': {
                'total_contacts': 0,
                'format_version': '1.0'
            }
        }
    
    def _save_log(self):
        """Save log data to JSON file"""
        self.data['station_info']['last_updated'] = datetime.now().isoformat()
        
        # Handle both old and new data formats
        if 'metadata' in self.data:
            self.data['metadata']['total_contacts'] = len(self.data['contacts'])
        
        with open(self.log_file, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)
    
    def _load_blog(self) -> Dict[str, Any]:
        """Load blog data from JSON file"""
        if not os.path.exists(self.blog_file):
            # Create default blog structure with sample posts
            default_blog = {
                'posts': [
                    {
                        'id': 1,
                        'title': 'Welcome to KM6KFX Amateur Radio Log',
                        'content': 'Welcome to my amateur radio station log! This blog will document my radio adventures, equipment updates, and interesting contacts. Stay tuned for updates on my latest QSOs and technical projects.',
                        'date': '2025-06-18',
                        'created_at': datetime.now().isoformat()
                    },
                    {
                        'id': 2,
                        'title': 'New ADIF Import System',
                        'content': 'Just implemented a new ADIF import system that can merge contacts from multiple log files while avoiding duplicates. The system now supports comment fields and handles RST reports properly for different modes like FT8.',
                        'date': '2025-06-18',
                        'created_at': datetime.now().isoformat()
                    },
                    {
                        'id': 3,
                        'title': 'Station Upgrade - New Antenna',
                        'content': 'Finally got the new G5RV antenna installed! Initial tests show significant improvement on 40m and 20m bands. Looking forward to working more DX with this setup. The SWR is looking great across the HF bands.',
                        'date': '2025-06-17',
                        'created_at': datetime.now().isoformat()
                    },
                    {
                        'id': 4,
                        'title': 'FT8 Adventures',
                        'content': 'Been exploring FT8 mode lately and amazed by the weak signal performance. Made contacts to over 15 countries this week with just 25 watts! The digital modes are really opening up new possibilities for QRP operation.',
                        'date': '2025-06-16',
                        'created_at': datetime.now().isoformat()
                    }
                ],
                'created_date': datetime.now().isoformat(),
                'last_updated': datetime.now().isoformat()
            }
            with open(self.blog_file, 'w', encoding='utf-8') as f:
                json.dump(default_blog, f, indent=2, ensure_ascii=False)
            return default_blog
        
        try:
            with open(self.blog_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {
                'posts': [],
                'created_date': datetime.now().isoformat(),
                'last_updated': datetime.now().isoformat()
            }
    
    def _save_blog(self):
        """Save blog data to JSON file"""
        self.blog_data['last_updated'] = datetime.now().isoformat()
        with open(self.blog_file, 'w', encoding='utf-8') as f:
            json.dump(self.blog_data, f, indent=2, ensure_ascii=False)
    
    def get_blog_posts(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Get blog posts, sorted by date descending"""
        posts = sorted(self.blog_data['posts'], key=lambda x: x.get('date', ''), reverse=True)
        if limit:
            return posts[:limit]
        return posts
    
    def get_blog_post(self, post_id: int) -> Optional[Dict[str, Any]]:
        """Get a specific blog post by ID"""
        for post in self.blog_data['posts']:
            if post.get('id') == post_id:
                return post
        return None
    
    def add_blog_post(self, title: str, content: str, date: Optional[str] = None) -> Dict[str, Any]:
        """Add a new blog post"""
        if date is None:
            date = datetime.now().strftime('%Y-%m-%d')
        
        # Generate new ID
        existing_ids = [post.get('id', 0) for post in self.blog_data['posts']]
        new_id = max(existing_ids, default=0) + 1
        
        new_post = {
            'id': new_id,
            'title': title,
            'content': content,
            'date': date,
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        self.blog_data['posts'].append(new_post)
        self._save_blog()
        return new_post
    
    def update_blog_post(self, post_id: int, title: str, content: str, date: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Update an existing blog post"""
        for i, post in enumerate(self.blog_data['posts']):
            if post.get('id') == post_id:
                self.blog_data['posts'][i]['title'] = title
                self.blog_data['posts'][i]['content'] = content
                if date:
                    self.blog_data['posts'][i]['date'] = date
                self.blog_data['posts'][i]['updated_at'] = datetime.now().isoformat()
                self._save_blog()
                return self.blog_data['posts'][i]
        return None
    
    def delete_blog_post(self, post_id: int) -> bool:
        """Delete a blog post"""
        for i, post in enumerate(self.blog_data['posts']):
            if post.get('id') == post_id:
                del self.blog_data['posts'][i]
                self._save_blog()
                return True
        return False
    
    def get_contact_key(self, contact: Dict[str, Any]) -> str:
        """Generate unique key for contact to detect duplicates"""
        call = contact.get('call', '')
        qso_date = contact.get('qso_date', '')
        time_on = contact.get('time_on', '')
        band = contact.get('band', '')
        mode = contact.get('mode', '')
        
        return f"{call}_{qso_date}_{time_on}_{band}_{mode}".upper()
    
    def add_contacts(self, new_contacts: List[Dict[str, Any]]) -> Dict[str, int]:
        """Add new contacts and merge new fields into existing ones"""
        existing_contacts = {}
        
        # Build map of existing contacts by their unique keys
        for i, contact in enumerate(self.data['contacts']):
            key = self.get_contact_key(contact)
            existing_contacts[key] = i
        
        added_count = 0
        updated_count = 0
        duplicate_count = 0
        
        for contact in new_contacts:
            key = self.get_contact_key(contact)
            
            if key not in existing_contacts:
                # Add import metadata for new contacts
                contact['imported_date'] = datetime.now().isoformat()
                contact['index'] = len(self.data['contacts'])
                self.data['contacts'].append(contact)
                added_count += 1
            else:
                # Update existing contact with new fields
                existing_index = existing_contacts[key]
                existing_contact = self.data['contacts'][existing_index]
                
                # Track if any fields were actually updated
                fields_updated = False
                
                # Merge new fields into existing contact
                for field_name, field_value in contact.items():
                    # Skip system fields that shouldn't be overwritten
                    if field_name in ['imported_date', 'index']:
                        continue
                    
                    # Add new fields or update existing ones if the new value is more complete
                    if field_name not in existing_contact:
                        existing_contact[field_name] = field_value
                        fields_updated = True
                    elif not existing_contact[field_name] and field_value:
                        # Update empty/null fields with new data
                        existing_contact[field_name] = field_value
                        fields_updated = True
                    elif field_value and str(field_value).strip() != str(existing_contact[field_name]).strip():
                        # Handle potential data differences (like different formatting)
                        # For now, keep existing data but could be enhanced for specific field rules
                        pass
                
                if fields_updated:
                    existing_contact['last_updated'] = datetime.now().isoformat()
                    updated_count += 1
                else:
                    duplicate_count += 1
        
        self._save_log()
        
        return {
            'added': added_count,
            'updated': updated_count,
            'duplicates': duplicate_count,
            'total': len(self.data['contacts'])
        }
    
    def get_all_contacts(self) -> List[Dict[str, Any]]:
        """Get all contacts"""
        return self.data['contacts']
    
    def get_contact_by_index(self, index: int) -> Optional[Dict[str, Any]]:
        """Get contact by index"""
        if 0 <= index < len(self.data['contacts']):
            contact = self.data['contacts'][index].copy()
            contact['index'] = index  # Add index for reference
            return contact
        return None
    
    def search_contacts(self, query: str = '', call: str = '', band: str = '', 
                       mode: str = '', date_from: str = '', date_to: str = '') -> List[Dict[str, Any]]:
        """Search contacts with filters"""
        results = []
        
        for i, contact in enumerate(self.data['contacts']):
            # Add index for reference
            contact_with_index = contact.copy()
            contact_with_index['index'] = i
            
            # Apply filters
            if query:
                search_fields = [
                    contact.get('call', ''),
                    contact.get('country', ''),
                    contact.get('state', '')
                ]
                if not any(query.lower() in field.lower() for field in search_fields if field):
                    continue
            
            if call and call.lower() not in contact.get('call', '').lower():
                continue
            
            if band and band.lower() != contact.get('band', '').lower():
                continue
            
            if mode and mode.lower() != contact.get('mode', '').lower():
                continue
            
            if date_from:
                contact_date = contact.get('qso_date', '')
                if contact_date and contact_date < date_from:
                    continue
            
            if date_to:
                contact_date = contact.get('qso_date', '')
                if contact_date and contact_date > date_to:
                    continue
            
            results.append(contact_with_index)
        
        return results
    
    def get_bands(self) -> List[str]:
        """Get unique bands from contacts"""
        bands = set()
        for contact in self.data['contacts']:
            band = contact.get('band')
            if band:
                bands.add(band)
        return sorted(list(bands))
    
    def get_modes(self) -> List[str]:
        """Get unique modes from contacts"""
        modes = set()
        for contact in self.data['contacts']:
            mode = contact.get('mode')
            if mode:
                modes.add(mode)
        return sorted(list(modes))
    
    def export_json(self) -> str:
        """Export log as JSON string"""
        return json.dumps(self.data, indent=2, ensure_ascii=False)
    
    def export_adif(self) -> str:
        """Export log as ADIF format"""
        adif_lines = []
        
        # Header
        station_call = self.data['station_info'].get('callsign', 'KM6KFX')
        adif_lines.append(f'<adif_ver:5>3.1.4')
        adif_lines.append(f'<programid:17>ADIF JSON Converter')
        adif_lines.append(f'<station_callsign:{len(station_call)}>{station_call}')
        adif_lines.append(f'<created_timestamp:15>{datetime.now().strftime("%Y%m%d %H%M%S")}')
        adif_lines.append('<eoh>')
        adif_lines.append('')
        
        # Contacts
        for contact in self.data['contacts']:
            contact_line = ''
            
            # Essential fields
            if contact.get('call'):
                call = contact['call']
                contact_line += f'<call:{len(call)}>{call}'
            
            if contact.get('qso_date'):
                qso_date = contact['qso_date'].replace('-', '')
                contact_line += f'<qso_date:8>{qso_date}'
            
            if contact.get('time_on'):
                time_on = contact['time_on'].replace(':', '')
                contact_line += f'<time_on:6>{time_on}'
            
            if contact.get('time_off'):
                time_off = contact['time_off'].replace(':', '')
                contact_line += f'<time_off:6>{time_off}'
            
            if contact.get('band'):
                band = contact['band']
                contact_line += f'<band:{len(band)}>{band}'
            
            if contact.get('freq'):
                freq = str(contact['freq'])
                contact_line += f'<freq:{len(freq)}>{freq}'
            
            if contact.get('mode'):
                mode = contact['mode']
                contact_line += f'<mode:{len(mode)}>{mode}'
            
            if contact.get('submode'):
                submode = contact['submode']
                contact_line += f'<submode:{len(submode)}>{submode}'
            
            if contact.get('rst_sent'):
                rst_sent = contact['rst_sent']
                contact_line += f'<rst_sent:{len(rst_sent)}>{rst_sent}'
            
            if contact.get('rst_rcvd'):
                rst_rcvd = contact['rst_rcvd']
                contact_line += f'<rst_rcvd:{len(rst_rcvd)}>{rst_rcvd}'
            
            if contact.get('gridsquare'):
                gridsquare = contact['gridsquare']
                contact_line += f'<gridsquare:{len(gridsquare)}>{gridsquare}'
            
            if contact.get('country'):
                country = contact['country']
                contact_line += f'<country:{len(country)}>{country}'
            
            if contact.get('state'):
                state = contact['state']
                contact_line += f'<state:{len(state)}>{state}'
            
            if contact.get('county'):
                county = contact['county']
                contact_line += f'<county:{len(county)}>{county}'
            
            if contact.get('station_callsign'):
                station_callsign = contact['station_callsign']
                contact_line += f'<station_callsign:{len(station_callsign)}>{station_callsign}'
            
            if contact.get('operator'):
                operator = contact['operator']
                contact_line += f'<operator:{len(operator)}>{operator}'
            
            if contact.get('qsl_sent'):
                qsl_sent = contact['qsl_sent']
                contact_line += f'<qsl_sent:{len(qsl_sent)}>{qsl_sent}'
            
            if contact.get('qsl_rcvd'):
                qsl_rcvd = contact['qsl_rcvd']
                contact_line += f'<qsl_rcvd:{len(qsl_rcvd)}>{qsl_rcvd}'
            
            if contact.get('contest_id'):
                contest_id = contact['contest_id']
                contact_line += f'<contest_id:{len(contest_id)}>{contest_id}'
            
            if contact.get('srx'):
                srx = contact['srx']
                contact_line += f'<srx:{len(srx)}>{srx}'
            
            if contact.get('stx'):
                stx = contact['stx']
                contact_line += f'<stx:{len(stx)}>{stx}'
            
            contact_line += '<eor>'
            adif_lines.append(contact_line)
        
        return '\n'.join(adif_lines)
    
    def get_log_stats(self) -> Dict[str, Any]:
        """Get log statistics"""
        contacts = self.data['contacts']
        
        if not contacts:
            return {
                'total_contacts': 0,
                'last_updated': self.data['station_info'].get('last_updated'),
                'created_date': self.data['station_info'].get('created_date'),
                'latest_qso_date': None,
                'bands_worked': [],
                'modes_used': [],
                'countries_worked': [],
                'states_worked': []
            }
        
        # Get latest QSO date
        qso_dates = [c.get('qso_date') for c in contacts if c.get('qso_date')]
        latest_qso_date = max(qso_dates) if qso_dates else None
        
        # Get unique values
        bands_worked = list(set(c.get('band') for c in contacts if c.get('band')))
        modes_used = list(set(c.get('mode') for c in contacts if c.get('mode')))
        countries_worked = list(set(c.get('country') for c in contacts if c.get('country')))
        states_worked = list(set(c.get('state') for c in contacts if c.get('state')))
        
        return {
            'total_contacts': len(contacts),
            'last_updated': self.data['station_info'].get('last_updated'),
            'created_date': self.data['station_info'].get('created_date'),
            'latest_qso_date': latest_qso_date,
            'bands_worked': sorted(bands_worked),
            'modes_used': sorted(modes_used),
            'countries_worked': sorted(countries_worked),
            'states_worked': sorted(states_worked)
        }

# Global log manager instance
log_manager = LogManager()