# ADIF to JSON Converter

## Overview

This is a Flask web application designed to convert amateur radio ADIF (Amateur Data Interchange Format) log files to standardized JSON format. The application uses portable JSON file storage for single-user amateur radio station logging, providing comprehensive data cleaning, incremental import capabilities, search functionality, and QSL card generation for amateur radio operators.

## System Architecture

### Frontend Architecture
- **Framework**: Server-side rendered Flask templates with Bootstrap 5
- **Theme**: Bootstrap dark theme optimized for Replit environment
- **JavaScript**: Vanilla JS for form enhancements and search functionality
- **Icons**: Feather Icons for consistent UI elements

### Backend Architecture
- **Framework**: Flask 3.1.1 with Gunicorn WSGI server
- **Storage**: JSON file-based storage system (`station_log.json`)
- **File Processing**: Custom ADIF parser with regex-based field extraction
- **Image Generation**: Pillow (PIL) for QSL card generation

### Data Storage Architecture
- **Single JSON File**: `station_log.json` contains all station data
  - Header information (station callsign, operator, timestamps, statistics)
  - Complete contact records with all ADIF fields
  - Incremental import capability with duplicate detection
- **LogManager Class**: Handles all JSON file operations
  - Contact addition with duplicate prevention
  - Search and filtering capabilities
  - Export functionality (JSON and ADIF formats)

## Key Components

### 1. ADIF Parser (`adif_parser.py`)
- Parses standard ADIF format files with regex patterns
- Handles field mappings and data type conversions
- Implements comprehensive data cleaning and standardization
- Supports various date/time formats and field variations

### 2. Log Manager (`models.py`)
- LogManager class for JSON file operations
- Contact duplicate detection using unique key generation
- Search and filtering with pagination support
- Export functionality for JSON and ADIF formats

### 3. Route Handlers (`routes.py`)
- File upload and processing with incremental import
- Station log viewing and contact details
- Advanced search and filtering functionality
- JSON and ADIF export capabilities
- QSL card generation endpoints

### 4. QSL Generator (`qsl_generator.py`)
- PIL-based QSL card image generation
- Customizable card layouts and styling
- Font fallback handling for deployment environments

## Data Flow

1. **Upload Process**:
   - User uploads ADIF file through web interface
   - File is validated and saved with timestamp prefix
   - ADIF parser extracts and cleans contact data
   - LogManager adds only new contacts to station_log.json, avoiding duplicates

2. **Search Process**:
   - Users can search across multiple fields (call, band, mode, date range)
   - LogManager filters contacts in memory for fast response
   - Results are paginated and displayed with export options

3. **Export Process**:
   - Complete station log can be exported as clean JSON or ADIF format
   - Data cleaning ensures consistency across amateur radio standards
   - Files can be downloaded or viewed in browser

## External Dependencies

### Python Packages
- **Flask 3.1.1**: Web framework
- **Pillow 11.2.1**: Image processing for QSL cards
- **Gunicorn 23.0.0**: Production WSGI server

### System Dependencies
- **Font libraries**: For QSL card text rendering
- **Image libraries**: libjpeg, libpng, libtiff for image processing

## Deployment Strategy

### Replit Configuration
- **Runtime**: Python 3.11 with Nix package manager
- **Deployment**: Autoscale deployment target
- **Process**: Gunicorn with bind to 0.0.0.0:5000
- **Development**: Hot reload enabled for development workflow

### Environment Variables
- `SESSION_SECRET`: Flask session secret key

### File Handling
- Upload directory created automatically
- 16MB maximum file size limit
- Secure filename handling with timestamp prefixes

## Changelog
- June 13, 2025: Initial setup with database architecture
- June 14, 2025: Major architectural change - migrated from SQLAlchemy database to JSON file storage
  - Implemented LogManager class for JSON operations
  - Added incremental import with duplicate detection
  - Fixed all template compatibility issues for JSON data
  - Updated routing to use contact index instead of database IDs
  - Improved portability - single station_log.json file contains all data
- June 18, 2025: Transformed into public log blog with protected admin interface
  - Added session-based authentication system (Username: KM6KFX, Password: happyham)
  - Created public-facing log blog displaying recent contacts and statistics
  - Protected ADIF upload and export functionality behind admin login
  - Enhanced merge functionality for reimporting ADIF files with new data
  - Improved RST signal report handling for different operating modes
  - Added comment field support for ADIF imports
  - Implemented complete blog system with JSON storage for blog posts
  - Limited home page to show last 10 contacts with link to full contact list
  - Added blog navigation and latest 4 blog entries display on home page
  - Created dedicated blog pages for all posts and individual post viewing
- June 19, 2025: UI consistency improvements and security enhancements
  - Standardized header navigation across all pages with consistent left/right layout
  - Added contextual action buttons and descriptive subtitles to all page headers
  - Updated navigation to include proper icons and uniform structure
  - Fixed security vulnerability by removing fallback secret key in app.py
  - Applied BASELINE.md standards with security scanning and README updates
  - Enhanced blog management with rich editor features and preview functionality
  - Improved navigation consistency between public_log.html and base.html templates
- June 20, 2025: Navigation order standardization and comprehensive UI/UX consistency
  - Fixed reversed Blog/All Contacts navigation links on all pages
  - Established consistent navigation order: Home → Blog → All Contacts → Search → Admin
  - Updated all template files (public_log.html, admin_panel.html, base.html) for uniformity
  - Standardized Bootstrap theme across all templates using Replit Bootstrap dark theme
  - Implemented dynamic active navigation states for proper page highlighting
  - Enhanced custom CSS with comprehensive styling for cards, forms, tables, and responsive design
  - Fixed Bootstrap JavaScript version inconsistencies across all templates
  - Applied BASELINE.md standards with security verification and documentation updates
- June 21, 2025: Complete Solarized theme selector implementation with accessibility improvements
  - Implemented official Solarized color palette with CSS variables for light/dark themes
  - Added theme selector dropdown with sun/moon icons to all navigation bars
  - Created JavaScript theme switching with localStorage persistence
  - Fixed text contrast issues in light theme with comprehensive color overrides
  - Resolved color combinations (green on orange) for proper accessibility
  - Applied Solarized styling to all components: buttons, alerts, badges, forms, tables
  - Enhanced theme selector with proper hover states and responsive design
  - Fixed QSL status display logic to show proper labels instead of raw Y/N values
  - Enhanced QSL status processing in ADIF parser with standardized value mappings
  - Updated templates to display "Confirmed", "Requested", "Not Sent/Received" labels
  - Improved QSL status handling for LoTW data that lacks QSL sent information

## User Preferences

Preferred communication style: Simple, everyday language.

**Automatic Baseline Standards**: After each code change, automatically run the standards defined in BASELINE.md:
1. Security scanning and fixes (without breaking functionality)
2. Check the webapp navigation and routing for consistency 
3. README.md updates to reflect latest features and implementation