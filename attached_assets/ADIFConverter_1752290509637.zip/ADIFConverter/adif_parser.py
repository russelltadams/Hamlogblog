import re
import json
from datetime import datetime, date, time
from typing import Dict, List, Any, Optional, Tuple
import logging

logger = logging.getLogger(__name__)

class AdifParser:
    """Parser for ADIF (Amateur Data Interchange Format) files"""
    
    def __init__(self):
        self.field_pattern = re.compile(r'<([^>:]+)(?::(\d+)(?::([^>]+))?)?>([^<]*)', re.IGNORECASE)
        self.header_pattern = re.compile(r'^(.*?)<eoh>', re.DOTALL | re.IGNORECASE)
        self.record_pattern = re.compile(r'<eor>', re.IGNORECASE)
        
        # Common ADIF field mappings and cleaning rules
        self.field_mappings = {
            'call': 'call',
            'callsign': 'call',
            'qso_date': 'qso_date',
            'qsodate': 'qso_date',
            'date': 'qso_date',
            'time_on': 'time_on',
            'timeon': 'time_on',
            'time': 'time_on',
            'time_off': 'time_off',
            'timeoff': 'time_off',
            'band': 'band',
            'freq': 'freq',
            'frequency': 'freq',
            'mode': 'mode',
            'submode': 'submode',
            'rst_sent': 'rst_sent',
            'rstsent': 'rst_sent',
            'rst_rcvd': 'rst_rcvd',
            'rstrcvd': 'rst_rcvd',
            'gridsquare': 'gridsquare',
            'grid': 'gridsquare',
            'country': 'country',
            'state': 'state',
            'county': 'county',
            'station_callsign': 'station_callsign',
            'stationcallsign': 'station_callsign',
            'operator': 'operator',
            'qsl_sent': 'qsl_sent',
            'qslsent': 'qsl_sent',
            'qsl_rcvd': 'qsl_rcvd',
            'qslrcvd': 'qsl_rcvd',
            'contest_id': 'contest_id',
            'contestid': 'contest_id',
            'srx': 'srx',
            'stx': 'stx',
            'comment': 'comment',
            'comments': 'comment',
            'notes': 'notes',
            'remarks': 'remarks'
        }
        
        # Band standardization
        self.band_mappings = {
            '160m': '160M', '80m': '80M', '40m': '40M', '30m': '30M',
            '20m': '20M', '17m': '17M', '15m': '15M', '12m': '12M',
            '10m': '10M', '6m': '6M', '4m': '4M', '2m': '2M',
            '70cm': '70CM', '23cm': '23CM', '13cm': '13CM',
            '160': '160M', '80': '80M', '40': '40M', '30': '30M',
            '20': '20M', '17': '17M', '15': '15M', '12': '12M',
            '10': '10M', '6': '6M', '4': '4M', '2': '2M'
        }
        
        # Mode standardization
        self.mode_mappings = {
            'cw': 'CW', 'ssb': 'SSB', 'fm': 'FM', 'am': 'AM',
            'rtty': 'RTTY', 'psk31': 'PSK31', 'ft8': 'FT8',
            'ft4': 'FT4', 'js8': 'JS8', 'msk144': 'MSK144',
            'phone': 'SSB', 'usb': 'USB', 'lsb': 'LSB'
        }

    def parse_file(self, file_path: str) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
        """Parse ADIF file and return header info and contact records"""
        try:
            # Try different encodings
            encodings = ['utf-8', 'latin-1', 'cp1252', 'ascii']
            content = None
            
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    logger.debug(f"Successfully read file with {encoding} encoding")
                    break
                except UnicodeDecodeError:
                    continue
            
            if content is None:
                raise ValueError("Could not decode file with any supported encoding")
            
            return self.parse_content(content)
            
        except Exception as e:
            logger.error(f"Error parsing ADIF file {file_path}: {str(e)}")
            raise

    def parse_content(self, content: str) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
        """Parse ADIF content string"""
        # Extract header
        header_match = self.header_pattern.search(content)
        header_info = {}
        
        if header_match:
            header_content = header_match.group(1)
            header_info = self._parse_header(header_content)
            # Remove header from content
            content = content[header_match.end():]
        
        # Split into records
        records = self.record_pattern.split(content)
        contacts = []
        
        for record in records:
            record = record.strip()
            if not record:
                continue
                
            try:
                contact = self._parse_record(record)
                if contact:
                    contacts.append(contact)
            except Exception as e:
                logger.warning(f"Error parsing record: {str(e)}")
                continue
        
        logger.info(f"Parsed {len(contacts)} contacts from ADIF content")
        return header_info, contacts

    def _parse_header(self, header_content: str) -> Dict[str, Any]:
        """Parse ADIF header information"""
        header_info = {}
        
        for match in self.field_pattern.finditer(header_content):
            field_name = match.group(1).lower()
            length = match.group(2)
            data_type = match.group(3)
            value = match.group(4)
            
            if length:
                value = value[:int(length)]
            
            header_info[field_name] = value.strip()
        
        return header_info

    def _parse_record(self, record_content: str) -> Optional[Dict[str, Any]]:
        """Parse individual ADIF record"""
        fields = {}
        
        for match in self.field_pattern.finditer(record_content):
            field_name = match.group(1).lower()
            length = match.group(2)
            data_type = match.group(3)
            value = match.group(4)
            
            if length:
                value = value[:int(length)]
            
            value = value.strip()
            if not value:
                continue
            
            # Clean and standardize field
            cleaned_value = self._clean_field_value(field_name, value)
            
            # Map field name to standard name
            standard_field = self.field_mappings.get(field_name, field_name)
            fields[standard_field] = cleaned_value
        
        # Must have at least a call sign to be valid
        if 'call' not in fields:
            return None
        
        # Convert date/time fields
        fields = self._process_datetime_fields(fields)
        
        return fields

    def _clean_field_value(self, field_name: str, value: str) -> str:
        """Clean and standardize field values"""
        value = value.strip()
        
        # Call sign cleaning
        if field_name in ['call', 'callsign', 'station_callsign', 'stationcallsign']:
            value = value.upper().replace(' ', '')
        
        # Band standardization
        elif field_name == 'band':
            value_lower = value.lower()
            if value_lower in self.band_mappings:
                value = self.band_mappings[value_lower]
            else:
                value = value.upper()
        
        # Mode standardization
        elif field_name == 'mode':
            value_lower = value.lower()
            if value_lower in self.mode_mappings:
                value = self.mode_mappings[value_lower]
            else:
                value = value.upper()
        
        # Grid square standardization
        elif field_name in ['gridsquare', 'grid']:
            # Grid squares should be 4 or 6 characters
            value = value.upper()
            if len(value) >= 4:
                # First two should be letters, next two numbers
                if value[:2].isalpha() and value[2:4].isdigit():
                    value = value[:4] if len(value) == 4 else value[:6]
        
        # Country standardization
        elif field_name == 'country':
            value = value.title()
        
        # State/Province standardization
        elif field_name in ['state', 've_prov']:
            value = value.upper()
        
        # Frequency conversion (ensure it's a valid number)
        elif field_name in ['freq', 'frequency']:
            try:
                float(value)
            except ValueError:
                logger.warning(f"Invalid frequency value: {value}")
                value = ""
        
        # QSL status standardization
        elif field_name in ['qsl_sent', 'qsl_rcvd']:
            value = value.upper()
            # Standardize QSL status values
            if value in ['Y', 'YES', '1', 'TRUE', 'SENT', 'RECEIVED', 'CONFIRMED']:
                value = 'Y'
            elif value in ['N', 'NO', '0', 'FALSE', 'NOT SENT', 'NOT RECEIVED']:
                value = 'N'
            elif value in ['R', 'REQUESTED']:
                value = 'R'
            elif value in ['I', 'INVALID', 'IGNORE']:
                value = 'I'
            elif value in ['V', 'VERIFIED']:
                value = 'V'
            else:
                # If unclear, default to N for sent, keep original for received
                if field_name == 'qsl_sent' and value not in ['Y', 'N', 'R', 'I', 'V']:
                    value = 'N'
        
        return value

    def _process_datetime_fields(self, fields: Dict[str, Any]) -> Dict[str, Any]:
        """Process and standardize date/time fields"""
        processed = fields.copy()
        
        # Process QSO date
        if 'qso_date' in fields:
            processed['qso_date'] = self._parse_date(fields['qso_date'])
        
        # Process times
        for time_field in ['time_on', 'time_off']:
            if time_field in fields:
                processed[time_field] = self._parse_time(fields[time_field])
        
        # Process QSL dates
        for date_field in ['qsl_sent_date', 'qsl_rcvd_date']:
            if date_field in fields:
                processed[date_field] = self._parse_date(fields[date_field])
        
        return processed

    def _parse_date(self, date_str: str) -> Optional[str]:
        """Parse various date formats to ISO format (YYYY-MM-DD)"""
        if not date_str:
            return None
        
        date_str = date_str.strip()
        
        # Common ADIF date formats
        date_formats = [
            '%Y%m%d',      # YYYYMMDD (ADIF standard)
            '%Y-%m-%d',    # YYYY-MM-DD
            '%m/%d/%Y',    # MM/DD/YYYY
            '%d/%m/%Y',    # DD/MM/YYYY
            '%Y/%m/%d',    # YYYY/MM/DD
            '%d-%m-%Y',    # DD-MM-YYYY
            '%m-%d-%Y',    # MM-DD-YYYY
            '%Y.%m.%d',    # YYYY.MM.DD
            '%d.%m.%Y',    # DD.MM.YYYY
        ]
        
        for fmt in date_formats:
            try:
                parsed_date = datetime.strptime(date_str, fmt).date()
                return parsed_date.isoformat()
            except ValueError:
                continue
        
        logger.warning(f"Could not parse date: {date_str}")
        return None

    def _parse_time(self, time_str: str) -> Optional[str]:
        """Parse various time formats to HH:MM:SS format"""
        if not time_str:
            return None
        
        time_str = time_str.strip()
        
        # Common ADIF time formats
        time_formats = [
            '%H%M%S',      # HHMMSS (ADIF standard)
            '%H%M',        # HHMM
            '%H:%M:%S',    # HH:MM:SS
            '%H:%M',       # HH:MM
            '%H.%M.%S',    # HH.MM.SS
            '%H.%M',       # HH.MM
        ]
        
        for fmt in time_formats:
            try:
                parsed_time = datetime.strptime(time_str, fmt).time()
                return parsed_time.strftime('%H:%M:%S')
            except ValueError:
                continue
        
        logger.warning(f"Could not parse time: {time_str}")
        return None

    def export_to_json(self, header_info: Dict[str, Any], contacts: List[Dict[str, Any]], 
                      pretty_print: bool = True) -> str:
        """Export parsed data to JSON format"""
        export_data = {
            'header': header_info,
            'contacts': contacts,
            'metadata': {
                'total_contacts': len(contacts),
                'export_date': datetime.utcnow().isoformat(),
                'format_version': '1.0'
            }
        }
        
        if pretty_print:
            return json.dumps(export_data, indent=2, ensure_ascii=False)
        else:
            return json.dumps(export_data, ensure_ascii=False)
