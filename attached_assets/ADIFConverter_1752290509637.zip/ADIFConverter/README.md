# KM6KFX Amateur Radio Log Blog

A comprehensive Flask web application that functions as both a public amateur radio log blog and a private admin management system. Features ADIF log file processing, clean JSON storage, advanced search functionality, and QSL card generation. Perfect for amateur radio operators who want to share their contacts publicly while maintaining private control over log management.

## Features

### Core Functionality
- **ADIF Parsing**: Supports standard ADIF log files (.adi, .adif, .txt formats)
- **Data Cleaning**: Automatically fixes common inconsistencies in amateur radio logs
- **Portable JSON Storage**: Single-file JSON storage system for maximum portability
- **Incremental Imports**: Adds new contacts and merges additional fields into existing contacts on subsequent uploads
- **Advanced Search**: Multi-field search functionality across all imported contacts
- **QSL Card Generation**: Create professional QSL cards dynamically from contact data
- **Contact Details**: Detailed view of individual contacts with all available information
- **QRZ Integration**: Direct links to QRZ.com for call sign lookups

### Data Cleaning & Standardization
- **Date/Time Normalization**: Converts various date/time formats to ISO standard
  - Supports formats: YYYYMMDD, YYYY-MM-DD, MM/DD/YYYY, DD/MM/YYYY, and more
  - Time formats: HHMMSS, HH:MM:SS, HHMM, HH:MM
- **Call Sign Cleaning**: Standardizes call sign formatting and removes invalid characters
- **Band Standardization**: Normalizes band designations (e.g., "20m" → "20M", "160" → "160M")
- **Mode Standardization**: Standardizes mode names (e.g., "cw" → "CW", "ssb" → "SSB")
- **RST Signal Report Handling**: Intelligent display based on operating mode
  - Traditional modes (CW, SSB, AM, FM): Shows RST values when available
  - Digital modes (FT8, FT4, JS8, etc.): Shows "N/A (Mode)" since RST not applicable
  - Consistent handling across all views and QSL card generation
- **Grid Square Validation**: Validates and formats Maidenhead grid squares (4 or 6 characters)
- **Frequency Validation**: Ensures frequency values are valid numbers
- **Case Normalization**: Fixes inconsistent capitalization across fields
- **Country/State Standardization**: Proper case formatting for location data

### Web Interface Features
- **Public Log Blog**: Beautiful public-facing interface displaying recent contacts and station statistics
- **Complete Blog System**: Full-featured blog functionality with amateur radio articles and technical updates
  - Latest 4 blog entries displayed on home page with excerpts
  - Dedicated blog page with all posts sorted by date
  - Individual blog post pages with full content and metadata
  - Admin blog management with create, edit, and delete capabilities
  - Rich text editor with preview functionality for blog posts
- **Protected Admin Panel**: Secure admin interface for log management (Username: KM6KFX, Password: happyham)
  - ADIF file upload and processing
  - Blog post management and authoring tools
  - Export functionality for JSON and ADIF formats
  - Comprehensive log statistics and management
- **Consistent Navigation**: Uniform header styling and navigation order across all pages (Home → Blog → All Contacts → Search) with dynamic active states and contextual action buttons
- **Modern UI**: Replit Bootstrap dark theme with comprehensive CSS customizations for consistent styling across all pages
- **Session-Based Authentication**: Simple login system protecting sensitive functions
- **Recent Contacts Display**: Home page shows last 10 contacts with link to full contact list
- **Search & Filter**: 
  - General text search across call signs, countries, and states
  - Specific filters for call sign, band, mode, and date ranges
  - Auto-complete functionality for bands and modes
- **Pagination**: Efficient handling of large log files on dedicated contact list page
- **Protected Export Options**: Admin-only access to JSON and ADIF downloads
- **QSL Card Generation**: PNG format QSL cards with professional layout
- **Contact Management**: Individual contact detail pages with complete QSO information

## Installation

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Local Setup
1. Clone or download the application files
2. Install required dependencies:
```bash
pip install flask pillow gunicorn
```

3. Set up environment variables (optional):
```bash
export SESSION_SECRET="your-secret-key-here"
```

4. Start the application:
```bash
python main.py
```

The application will be available at `http://localhost:5000`

**Note**: The application uses a single JSON file (`station_log.json`) for data storage, making it completely portable and requiring no database setup.

### Production Deployment
For production environments, use Gunicorn:
```bash
gunicorn --bind 0.0.0.0:5000 --workers 4 main:app
```

## Usage

### 1. Public Interface
- **Home Page**: View recent contacts, station statistics, and latest blog entries
- **Blog**: Read amateur radio articles and technical updates
- **All Contacts**: Browse the complete contact list with pagination
- **Search**: Find specific contacts using various filters

### 2. Admin Functions (Login Required)
#### Upload ADIF Files
1. Log in to the admin panel (Username: KM6KFX, Password: happyham)
2. Click "Select ADIF File" and choose your log file
3. Supported formats: `.adi`, `.adif`, `.txt`
4. Maximum file size: 16MB
5. Click "Upload and Convert"

**Note**: The application maintains a single station log. Subsequent uploads will only add new contacts, avoiding duplicates automatically.

#### Blog Management
1. Access "Blog Management" from the admin panel
2. Create new posts with the rich text editor
3. Edit existing posts with preview functionality
4. Delete posts as needed
5. All blog posts are stored in JSON format for portability

### 2. View and Manage Your Station Log
- **My Log Statistics**: Home page shows total contacts, bands, modes, and recent activity
- **Browse All Contacts**: View paginated list of all contacts in your station log
- **Export Data**: Download your complete log as clean JSON format
- **Incremental Updates**: Upload new ADIF files to add only new contacts

### 3. Search Contacts
- **General Search**: Enter call signs, countries, or states in the main search box
- **Advanced Filters**: Use specific filters for:
  - Call sign patterns
  - Band selection (dropdown)
  - Mode selection (dropdown)
  - Date ranges (from/to dates)
- **Keyboard Shortcuts**: 
  - `Ctrl+K` (or `Cmd+K` on Mac) to focus search
  - `Escape` to clear active search field

### 4. Contact Management
- **View Details**: Click "See Details" in any contact dropdown menu
- **Generate QSL Cards**: Create professional PNG QSL cards
- **QRZ Lookup**: Direct links to QRZ.com for additional information
- **Export Individual Contacts**: Part of log export functionality

## ADIF Field Support

### Primary Fields (Directly Mapped)
- `CALL` - Call sign of contacted station
- `QSO_DATE` - Date of contact
- `TIME_ON` / `TIME_OFF` - Start/end times of contact
- `BAND` - Amateur radio band
- `FREQ` - Frequency in MHz
- `MODE` / `SUBMODE` - Operating mode and submode
- `RST_SENT` / `RST_RCVD` - Signal reports
- `GRIDSQUARE` - Maidenhead locator
- `COUNTRY` / `STATE` / `COUNTY` - Geographic location
- `STATION_CALLSIGN` - Operating station call sign
- `OPERATOR` - Operator call sign
- `QSL_SENT` / `QSL_RCVD` - QSL card status
- `QSL_SENT_DATE` / `QSL_RCVD_DATE` - QSL card dates
- `CONTEST_ID` - Contest identifier
- `SRX` / `STX` - Serial numbers (received/transmitted)
- `COMMENT` / `COMMENTS` - Contact comments and notes
- `NOTES` / `REMARKS` - Additional notes and remarks

### Additional Fields
Any ADIF field not listed above is stored in the `additional_fields` JSON column and displayed in the contact details view.

## Data Cleaning Examples

### Input ADIF Record
```
<call:6>KM6KFX<qso_date:8>20231015<time_on:4>1430<band:3>20m<mode:2>cw<rst_sent:3>599<rst_rcvd:3>599<gridsquare:6>CM87wk<country:13>United States<state:2>ca<eor>
```

### Cleaned Output
```json
{
  "call": "KM6KFX",
  "qso_date": "2023-10-15",
  "time_on": "14:30:00",
  "band": "20M",
  "mode": "CW",
  "rst_sent": "599",
  "rst_rcvd": "599",
  "gridsquare": "CM87WK",
  "country": "United States",
  "state": "CA"
}
```

### Common Issues Fixed
- **Date Formats**: `20231015` → `2023-10-15`
- **Time Formats**: `1430` → `14:30:00`
- **Band Names**: `20m` → `20M`
- **Mode Names**: `cw` → `CW`
- **Case Issues**: `ca` → `CA`, `CM87wk` → `CM87WK`
- **Call Signs**: `km6kfx` → `KM6KFX`

## QSL Card Generation

### Features
- Professional layout with contact information
- Station call sign from log header or contact data
- QSO details: date, time, band, mode, frequency
- Signal reports and location information
- QSL confirmation status
- Generated date timestamp

### Output Format
- **File Format**: PNG
- **Resolution**: 600x400 pixels
- **Filename**: `QSL_{CALL}_{DATE}.png`
- **Download**: Automatic download via browser

## API Endpoints

### File Upload
- **POST** `/upload` - Upload and process ADIF files
- **Content-Type**: `multipart/form-data`
- **Parameters**: `file` (ADIF file)

### Data Access
- **GET** `/` - Home page with station log statistics
- **GET** `/view_log` - View all contacts in station log
- **GET** `/contact/<int:contact_index>` - View individual contact details by index
- **GET** `/search` - Search contacts with optional parameters:
  - `q` - General search query
  - `call` - Call sign filter
  - `band` - Band filter
  - `mode` - Mode filter
  - `date_from` - Start date (YYYY-MM-DD)
  - `date_to` - End date (YYYY-MM-DD)
  - `page` - Page number for pagination

### Export and Generation
- **GET** `/export/json` - Export complete station log as JSON
- **GET** `/export/adif` - Export complete station log as ADIF
- **GET** `/qsl/<int:contact_index>` - Generate QSL card PNG for contact

## Data Storage

The application uses two primary JSON files for portable data storage:

### Station Log Structure (`station_log.json`)
All amateur radio contact data is stored in a single portable JSON file with the following structure:

```json
{
  "header": {
    "station_callsign": "KM6KFX",
    "operator": "KM6KFX",
    "created_timestamp": "2025-06-13T23:00:00Z",
    "last_updated": "2025-06-13T23:00:00Z",
    "total_contacts": 450,
    "adif_version": "3.1.4"
  },
  "contacts": [
    {
      "call": "W1AW",
      "qso_date": "2023-10-15",
      "time_on": "14:30:00",
      "band": "20M",
      "mode": "CW",
      "freq": "14.025",
      "rst_sent": "599",
      "rst_rcvd": "599",
      "gridsquare": "FM19",
      "country": "United States",
      "state": "CT"
    }
  ]
}
```

### Blog Data Structure (`blog_posts.json`)
All blog posts are stored in a separate JSON file for easy management:

```json
{
  "posts": [
    {
      "id": 1,
      "title": "Setting Up My First HF Station",
      "content": "After years of operating on VHF/UHF...",
      "date": "2024-01-15",
      "excerpt": "Getting started with HF operations and my first contacts on 20 meters."
    }
  ],
  "next_id": 2
}
```

### Benefits of JSON Storage
- **Portability**: Single files can be easily backed up, shared, or moved
- **No Database Required**: No setup or maintenance of database systems
- **Human Readable**: Can be viewed and edited with any text editor
- **Version Control Friendly**: Changes can be tracked with git or similar tools
- **Cross-Platform**: Works on any system with Python
- **Separate Concerns**: Log data and blog content stored independently

## File Structure
```
adif-converter/
├── app.py              # Flask application setup
├── main.py             # Application entry point
├── models.py           # JSON log manager and data models
├── routes.py           # URL routes and handlers
├── adif_parser.py      # ADIF parsing logic
├── qsl_generator.py    # QSL card generation
├── station_log.json    # Single JSON file containing all station data
├── templates/          # HTML templates
│   ├── base.html
│   ├── index.html
│   ├── search.html
│   ├── view_log.html
│   └── view_contact.html
├── static/             # CSS and JavaScript
│   ├── css/custom.css
│   └── js/search.js
└── uploads/            # Temporary file storage during upload
```

## Troubleshooting

### Common Issues

#### File Upload Errors
- **"File too large"**: Maximum file size is 16MB
- **"Invalid file type"**: Only .adi, .adif, .txt files supported
- **"No valid contacts found"**: Check ADIF file format and encoding

#### Parsing Errors
- **Date/Time Issues**: Ensure dates are in YYYYMMDD format
- **Encoding Problems**: Try saving ADIF file as UTF-8
- **Missing Fields**: Call sign is required for each contact

#### Search Issues
- **No Results**: Check filter criteria and date ranges
- **Slow Search**: Large databases may take time to search
- **Invalid Dates**: Use YYYY-MM-DD format for date filters

### Performance Optimization
- **JSON File**: Efficient for single-user station logs up to 50,000+ contacts
- **Memory Usage**: Entire log loaded into memory for fast searching
- **Pagination**: Large contact lists are automatically paginated for web display
- **File Backup**: Regular backups of `station_log.json` recommended

## Contributing

### Development Setup
1. Install development dependencies
2. Run in debug mode: `python main.py`
3. Access at `http://localhost:5000`

### Code Style
- Follow PEP 8 for Python code
- Use Bootstrap classes for consistent styling
- Add comments for complex parsing logic

## License

This project is designed for the amateur radio community. Feel free to use, modify, and distribute according to your needs.

## Support

For issues related to:
- **ADIF Parsing**: Check the ADIF specification
- **QSL Cards**: Verify contact data completeness
- **Database**: Ensure proper database setup
- **Performance**: Consider hardware requirements for large logs

---

**73 de Developer**  
*Happy logging!*
